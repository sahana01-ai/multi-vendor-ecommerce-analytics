const Review = require('../models/Review');

// CREATE a review
exports.createReview = async (req, res) => {
  try {
    const { productId, rating, comment } = req.body;

    // Prevent duplicate reviews from the same customer on the same product
    const existing = await Review.findOne({ product: productId, customer: req.user.id });
    if (existing) {
      return res.status(400).json({ message: 'You already reviewed this product' });
    }

    const review = new Review({
      product: productId,
      customer: req.user.id,
      rating,
      comment,
    });

    await review.save();
    res.status(201).json(review);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// GET all reviews for a product
exports.getProductReviews = async (req, res) => {
  try {
    const reviews = await Review.find({ product: req.params.productId })
      .populate('customer', 'name')
      .sort({ createdAt: -1 });
    res.json(reviews);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};