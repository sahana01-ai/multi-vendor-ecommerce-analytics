import { useState, useEffect } from 'react';
import API from '../api/axios';
import ProductCard from '../components/ProductCard';

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    API.get('/products')
      .then((res) => setProducts(res.data))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  const filtered = products.filter((p) =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      {/* Hero */}
      <div className="bg-ink text-white">
        <div className="max-w-6xl mx-auto px-4 py-16 text-center">
          <h1 className="font-display text-5xl mb-3">Shop from independent sellers</h1>
          <p className="text-white/70 mb-8">One marketplace, hundreds of small stores</p>
          <input
            type="text"
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full max-w-md mx-auto block rounded-lg px-4 py-3 text-ink outline-none focus:ring-2 focus:ring-marigold"
          />
        </div>
      </div>

      {/* Product Grid */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        {loading ? (
          <p className="text-center text-ink/50">Loading products...</p>
        ) : filtered.length === 0 ? (
          <p className="text-center text-ink/50">No products found.</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            {filtered.map((product) => (
              <ProductCard key={product._id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}