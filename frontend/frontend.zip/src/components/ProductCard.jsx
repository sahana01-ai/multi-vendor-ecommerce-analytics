import { Link } from 'react-router-dom';

export default function ProductCard({ product }) {
  return (
    <Link
      to={`/product/${product._id}`}
      className="group block bg-white border border-line rounded-xl overflow-hidden hover:border-marigold transition"
    >
      <div className="aspect-square bg-canvas overflow-hidden">
        <img
          src={product.imageUrl || 'https://via.placeholder.com/300'}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
        />
      </div>
      <div className="p-4">
        <p className="text-xs text-teal font-medium mb-1">{product.vendor?.storeName}</p>
        <h3 className="font-display text-lg text-ink mb-1 line-clamp-1">{product.name}</h3>
        <p className="text-ink font-semibold">₹{product.price}</p>
      </div>
    </Link>
  );
}